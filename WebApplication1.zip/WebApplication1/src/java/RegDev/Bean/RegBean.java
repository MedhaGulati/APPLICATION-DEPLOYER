/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package RegDev.Bean;

import fancy.dao.RegDevDAO;
import Common.DatabaseConn;
import Common.RegDev;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.bean.ManagedBean;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

/**
 *
 * @author Medha
 */
@ManagedBean(name="register")
public class RegBean implements java.io.Serializable,RegDevDAO{
     private String name;
     private String newpass;
     private String address;
     private String emailId;
     private int ph;
    
     public RegBean(){
         
     }
    
     public String store()
     {  int flag=0;
         String n=this.name;
         String np=this.newpass;
         String a=this.address;
         String email=this.emailId;
         int ph=this.ph;

          DatabaseConn db=new DatabaseConn();
        Connection c=db.dbConnection();
        String in = "insert into dev values('"+n+"','"+np+"','"+a+"','"+email+"','"+ph+"')";
         try {
     Statement stmt= c.createStatement();
       stmt.executeUpdate(in);
       flag=1;
         } catch (SQLException ex) {
             Logger.getLogger(RegBean.class.getName()).log(Level.SEVERE, null, ex);
         }
         
         
        
         
       if(flag==1)
           return("confirmationpg.jsp");
       else
         return "";
       
             
    
     }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the newpass
     */
    public String getNewpass() {
        return newpass;
    }

    /**
     * @param newpass the newpass to set
     */
    public void setNewpass(String newpass) {
        this.newpass = newpass;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the emailId
     */
    public String getEmailId() {
        return emailId;
    }

    /**
     * @param emailId the emailId to set
     */
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    /**
     * @return the ph
     */
    public int getPh() {
        return ph;
    }

    /**
     * @param ph the ph to set
     */
    public void setPh(int ph) {
        this.ph = ph;
    }

    
}
