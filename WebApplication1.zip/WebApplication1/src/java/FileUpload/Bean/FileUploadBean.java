/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package FileUpload.Bean;

import Common.DatabaseConn;
import RegDev.Bean.RegBean;
//import com.sun.xml.internal.ws.wsdl.writer.document.Part;
import devpaths.bean.DevpathBean;
import java.util.List;
import fancy.dao.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.*;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.view.facelets.FaceletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

/**
 *
 * @author Medha
 */

@ManagedBean(name = "upload")
@SessionScoped
public class FileUploadBean implements java.io.Serializable, FileUploadDAO {

    private String upath;
    private Part upfile;

    public FileUploadBean() {
    }

    private static String getFilename(Part part) {

        Pattern p = Pattern.compile(".*\\.jar");




        for (String cd : part.getHeader("content-disposition").split(";")) {
            if (cd.trim().startsWith("filename")) {
                String filename = cd.substring(cd.indexOf("") + 1).trim().replace("\"", "");
                Matcher m = p.matcher(filename);
                if (m.matches()) {
                    return filename.substring(filename.lastIndexOf('/') + 1).substring(filename.lastIndexOf('\\') + 1);

                }


            }

        }
        return null;

    }

    public String upload() throws IOException {
        DatabaseConn db = new DatabaseConn();
        Connection c = db.dbConnection();
        int flag = 0;
        String u = "vg@gmail.com";
        String sql = "select * from dev where emailid='" + u + "'";
        ResultSet rs = null;
        String up;

        String check = getFilename(upfile);
        if (check == null) {
            return "errorpg.xhtml";
        } else {
            try {
                Statement stmt = c.createStatement();
                rs = stmt.executeQuery(sql);


                if (rs.next()) {
                    up = rs.getString(6);
                    upfile.write(up + getFilename(upfile));
                    return "success";
                }
            } catch (Exception e) {
            }

            //"C:\\Users\\Medha\\Desktop\\nic doc\\"

        }
        return null;

    }

    public String conf() {
        int flag = 0;
//DevpathBean d=new DevpathBean();
//String e=d.getEmail();
        String e = "";
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
        e = (String) session.getAttribute("appEmail");
        String dp = this.getUpath();

        DatabaseConn db = new DatabaseConn();
        Connection c = db.dbConnection();
        String in = "update dev set fd='" + dp + "' where emailid='" + e + "'";
        try {
            Statement stmt = c.createStatement();
            stmt.executeUpdate(in);
            flag = 1;
        } catch (SQLException ex) {
            Logger.getLogger(RegBean.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            session.removeAttribute("appEmail");
        }




        if (flag == 1) {
            return ("confirmationpg.jsp");
        } else {
            return "";
        }


    }

    /**
     * @return the upath
     */
    public String getUpath() {
        return upath;
    }

    /**
     * @param upath the upath to set
     */
    public void setUpath(String upath) {
        this.upath = upath;
    }

    /**
     * @return the upfile
     */
    public Part getUpfile() {
        return upfile;
    }

    /**
     * @param upfile the upfile to set
     */
    public void setUpfile(Part upfile) {
        this.upfile = upfile;
    }
    /**
     * @return the upfile
     */
}
