/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package FileUpload.impl;

import Common.DatabaseConn;
import Common.User;
import fancy.dao.FileUploadDAO;
import fancy.dao.LoginDAO;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Medha
 */
public class FileUploadImpl implements FileUploadDAO{
    
        public void adduser(){
  

  
    }
}
