/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package login.bean;
import Common.DatabaseConn;
import Common.User;
import fancy.dao.LoginDAO;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.bean.ManagedBean;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Medha
 */
@ManagedBean(name="login")
public class LoginBean implements java.io.Serializable,LoginDAO{
    private String userId;
     private String password;
     public LoginBean(){
         
     }  
    
     public String checkUser() 
     {
         
        String u=this.userId;
        String p=this.password;

        DatabaseConn db=new DatabaseConn();
        Connection c=db.dbConnection();
        // and pass='\'+p+\''
        int flag=0;
 
         String sql = "select * from adm where username='"+u+"' and pass='"+p+"'"; //"insert into adm values('"+u+"','"+p+"')";
         String sql2 = "select * from dev where name='"+u+"' and pass='"+p+"'"; 
         
         ResultSet rs =null;
        try{Statement stmt =c.createStatement();
            rs = stmt.executeQuery(sql);
             
       
         if(rs.next())
             flag=1;
           
         
         else {
            
           rs = stmt.executeQuery(sql2);
           if(rs.next())
           flag=2;
           else
               flag=0;
            
         }
         
         
             
        }catch(Exception e){}
        if(flag==0)
{
 return "";
}else
            if(flag==1)
 return("admin.jsp");
        else
                return("dev.xhtml");
        
             
     
     }
     
            

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public List<User> getAllUsers() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public User getUser(String userId) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void updateUser(User user) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void deleteUser(User student) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }  
}

