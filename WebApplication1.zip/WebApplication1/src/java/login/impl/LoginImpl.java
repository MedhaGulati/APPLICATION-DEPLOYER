/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package login.impl;

import Common.User;
import fancy.dao.LoginDAO;
import java.util.List;

/**
 *
 * @author Medha
 */
public class LoginImpl implements LoginDAO{
    public LoginImpl()
    {
        
                
    }
    
    @Override
    public List<User> getAllUsers() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public User getUser(String userId) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void updateUser(User user) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void deleteUser(User student) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
 
}
