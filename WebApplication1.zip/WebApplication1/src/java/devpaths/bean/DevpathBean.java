/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package devpaths.bean;

import Common.DatabaseConn;
import fancy.dao.FileDownloadDAO;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Medha
 */
@ManagedBean(name = "path")
public class DevpathBean implements java.io.Serializable, FileDownloadDAO {

    private String email;

    public DevpathBean() {
    }

    public String dcheck() {


        DatabaseConn db = new DatabaseConn();
        Connection c = db.dbConnection();
        String e = this.getEmail();
        int flag = 0;

        String sql = "select * from dev where emailid='" + e + "'";

        try {
            Statement stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery(sql);


            if (rs.next()) {
                flag = 1;
                HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
                session.setAttribute("appEmail", e);
//         String y= "insert into dev(fd) values('"+dp+"')";
//         stmt.executeUpdate(y);
            } else {
                flag = 0;
            }


        } catch (Exception x) {
        }
        if (flag == 0) {
            return "";
        } else {
            return ("updown.xhtml");
        }


    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }
}
