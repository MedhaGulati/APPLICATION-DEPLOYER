/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Common;

/**
 *
 * @author Medha
 */
public class RegDev {
    private String name;
    private String address;
     private String emailId;
     private int ph;
     private String FileUpload;
     private String FileDownload;
private String newpass;

  public RegDev(String name,String newpass,String email,String address,int ph,String FileDownload,String FileUpload){
      this.name = name;
       this.newpass=newpass;
      this.emailId = emailId;
      this.address=address;
      this.ph= ph;
      this.FileDownload=FileDownload;
       this.FileUpload=FileUpload;
     
   }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the emailId
     */
    public String getEmailId() {
        return emailId;
    }

    /**
     * @param emailId the emailId to set
     */
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    /**
     * @return the ph
     */
    public int getPh() {
        return ph;
    }

    /**
     * @param ph the ph to set
     */
    public void setPh(int ph) {
        this.ph = ph;
    }

    /**
     * @return the FileUpload
     */
    public String getFileUpload() {
        return FileUpload;
    }

    /**
     * @param FileUpload the FileUpload to set
     */
    public void setFileUpload(String FileUpload) {
        this.FileUpload = FileUpload;
    }

    /**
     * @return the FileDownload
     */
    public String getFileDownload() {
        return FileDownload;
    }

    /**
     * @param FileDownload the FileDownload to set
     */
    public void setFileDownload(String FileDownload) {
        this.FileDownload = FileDownload;
    }

    /**
     * @return the newpass
     */
    public String getNewpass() {
        return newpass;
    }

    /**
     * @param newpass the newpass to set
     */
    public void setNewpass(String newpass) {
        this.newpass = newpass;
    }
}

    /**
     * @return the name
     */
   