/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Common;

/**
 *
 * @author Medha
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class DatabaseConn {

String url="jdbc:postgresql://localhost:5432/mydb";
String user="postgres";
String pass="root";

public Connection dbConnection(){
    Connection con=null;
    try{
    Class.forName("org.postgresql.Driver");
    }
    catch(ClassNotFoundException e)
    {
        System.out.println(e.getMessage());
    }
    try {
      con=  DriverManager.getConnection(url, user, pass);
       // JOptionPane.showMessageDialog(null,"Connected");
       
    } catch (SQLException ex) {
        Logger.getLogger(DatabaseConn.class.getName()).log(Level.SEVERE, null, ex);
         JOptionPane.showMessageDialog(null,"Failed Connected");
    }
     return con;
}
    
}