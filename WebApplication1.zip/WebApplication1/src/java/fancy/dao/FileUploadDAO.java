/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fancy.dao;
import Common.RegDev;
import java.util.List;

/**
 *
 * @author Medha
 */
import java.io.*;

public interface FileUploadDAO {


    
}
