/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fancy.dao;

/**
 *
 * @author Medha
 */
public interface FileDownloadDAO {
    
}
