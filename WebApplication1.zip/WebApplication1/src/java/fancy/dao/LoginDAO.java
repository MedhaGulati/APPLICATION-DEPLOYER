/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fancy.dao;
import Common.User;
import java.util.List;
/**
 *
 * @author Medha
 */
public interface LoginDAO {
     public List<User> getAllUsers();
   public User getUser(String userId);
   public void updateUser(User user);
   public void deleteUser(User student);
   
}
