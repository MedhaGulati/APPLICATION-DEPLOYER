/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package FileDownload.Impl;

import Common.DatabaseConn;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Medha
 */
public class FileDownloadImpl {
       
}


