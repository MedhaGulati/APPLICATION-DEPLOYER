/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package FileDownload.Bean;
import Common.DatabaseConn;
import fancy.dao.*;
import javax.faces.bean.ManagedBean;
import RegDev.Bean.RegBean;
import devpaths.bean.DevpathBean;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.Part;
/**
 *
 * @author Medha
 */
@ManagedBean(name="download")
public class FileDownloadBean  implements java.io.Serializable,FileDownloadDAO{
    private String dpath;
  private Part dfile;
    
    public FileDownloadBean() {
    }
public String config()
        
{   
    int flag=0;
DevpathBean d=new DevpathBean();
String e=d.getEmail();
        // String n=this.getName();
         String dp=this.getDpath();
        // String e=this.getEm();
         
        // String a=this.getAddress();
         //String email=this.getEmailId();
         //int ph=this.getPh();
//         String fu=this.getFileUpload();
//         String fd=this.getFileDownload();
          DatabaseConn db=new DatabaseConn();
        Connection c=db.dbConnection();
        String in = "update dev set fd='"+dp+"' where emailid='"+e+"'";
         try {
     Statement stmt= c.createStatement();
       stmt.executeUpdate(in);
       flag=1;
         } catch (SQLException ex) {
             Logger.getLogger(RegBean.class.getName()).log(Level.SEVERE, null, ex);
         }
         
         
        
         
         if(flag==1)
         return("confirmationpg.jsp");
         else
             return "";
  //  DevpathBean d = null;
//    String dp=this.getDpath();
//   // String e=d.getEmail();
// DatabaseConn db=new DatabaseConn();
//        Connection c=db.dbConnection();
//     
//        int flag=0;
// 
//         
//
//        try{
//         Statement stmt =c.createStatement();
//         String y= "update dev set fd='"+dp+"' where emailid='vg@gmail.com'";
//         stmt.executeUpdate(y);
//         flag=1;
//         }
//        catch(Exception x){}
//        if(flag==0)
//        {
//        return "";
//        }else
//        return ("admin.jsp");
//        
//             
}
public void download()
{
    
}
    /**
     * @return the dpath
     */
    public String getDpath() {
        return dpath;
    }

    /**
     * @param dpath the dpath to set
     */
    public void setDpath(String dpath) {
        this.dpath = dpath;
    }

    /**
     * @return the dfile
     */
    public Part getDfile() {
        return dfile;
    }

    /**
     * @param dfile the dfile to set
     */
    public void setDfile(Part dfile) {
        this.dfile = dfile;
    }

    /**
     * @return the em
     */
//    public String getEm() {
//        return em;
//    }
//
//    /**
//     * @param em the em to set
//     */
//    public void setEm(String em) {
//        this.em = em;
//    }

    /**
     * @return the email
     */
  
   
}
